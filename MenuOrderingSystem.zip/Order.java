import java.util.HashMap;
import java.util.Map;

// Class representing an order of menu items
public class Order {
    private Map<MenuItem, Integer> items; // Items and their quantities
    private double totalPrice; // Total price of the order

    // Constructor to initialize the order
    public Order() {
        items = new HashMap<>(); // Initialize items map
        totalPrice = 0.0; // Initialize total price
    }

    // Add item to the order
    public void addItem(MenuItem item) {
        items.put(item, items.getOrDefault(item, 0) + 1); // Update quantity
        totalPrice += item.getPrice(); // Update total price
    }

    // Get order summary as a string
    public String getSummary() {
        StringBuilder summary = new StringBuilder(); // StringBuilder for summary
        summary.append("Order Summary:\n");
        for (Map.Entry<MenuItem, Integer> entry : items.entrySet()) {
            MenuItem item = entry.getKey(); // Get menu item
            int count = entry.getValue(); // Get quantity
            summary.append(item.getName()).append(": ").append(count).append(" ordered\n");
        }
        summary.append("\nTotal Price: $").append(String.format("%.2f", totalPrice)); // Append total price
        return summary.toString(); // Return summary
    }

    // Get total price of the order
    public double getTotalPrice() {
        return totalPrice; // Return total price
    }

    // Get items in the order
    public Map<MenuItem, Integer> getItems() {
        return items; // Return items map
    }
}
