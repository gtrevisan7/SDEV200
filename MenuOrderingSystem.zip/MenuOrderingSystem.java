import javax.swing.*; // Swing components for GUI
import java.awt.*; // AWT layout and event handling
import java.awt.event.*; // AWT event classes
import java.io.*; // I/O classes
import java.util.ArrayList; // Dynamic array list
import java.util.HashMap; // Key-value pairs
import java.util.List; // List interface
import java.util.Map; // Map interface


// Main class for the menu ordering system
public class MenuOrderingSystem {
    private List<MenuItem> menuItems = new ArrayList<>(); // List of menu items
    private Map<MenuItem, Integer> orderSummary = new HashMap<>(); // Ordered items and quantities
    private double totalPrice = 0.0; // Total price of the order
    private double taxRate = 0.0; // Tax rate as a percentage
    private JTextArea messageArea; // Area for displaying messages

    // Constructor to initialize the system
    public MenuOrderingSystem() {
        askForTax(); // Ask if tax will be applied
        loadMenuItems(); // Load menu items from file
        createAndShowGUI(); // Create and show GUI
    }

    // Ask if tax will be applied and set tax rate
    // Ask if tax will be applied and set tax rate
private void askForTax() {
    int response = JOptionPane.showConfirmDialog(null, "Will tax be applied to your order?", "Tax Confirmation", JOptionPane.YES_NO_OPTION);
    
    if (response == JOptionPane.YES_OPTION) {
        String taxInput;
        while (true) {
            taxInput = JOptionPane.showInputDialog("Enter the tax percentage (e.g., 7.5 for 7.5%):");
            try {
                double taxPercentage = Double.parseDouble(taxInput);
                if (taxPercentage >= 0) {
                    taxRate = taxPercentage / 100; // Convert to decimal
                    break; // Exit loop if input is valid
                } else {
                    JOptionPane.showMessageDialog(null, "Error: Tax percentage cannot be negative. Please enter a valid value.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid tax percentage entered. Please enter a valid number.");
            }
        }
    }
}


    // Load menu items from a text file
    private void loadMenuItems() {
        try (BufferedReader reader = new BufferedReader(new FileReader("menu.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                String name = parts[0];
                double price = Double.parseDouble(parts[1]);

                // Check for negative or zero price
                if (price <= 0) {
                    JOptionPane.showMessageDialog(null, "Error: The price of \"" + name + "\" is invalid: $" + price);
                    System.exit(1); // Exit the program
                }

                menuItems.add(new MenuItem(name, price));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading menu file: " + e.getMessage());
            System.exit(1); // Exit the program on file read error
        }
    }
    
    // Create and display the GUI
    private void createAndShowGUI() {
        JFrame frame = new JFrame("Menu Ordering System"); // Main window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close operation
        frame.setSize(400, 300); // Window size
        frame.setLayout(new BorderLayout()); // Layout manager

        DefaultListModel<MenuItem> listModel = new DefaultListModel<>(); // Model for JList
        for (MenuItem item : menuItems) {
            listModel.addElement(item); // Add items to the model
        }

        JList<MenuItem> menuList = new JList<>(listModel); // Create JList for menu items
        JScrollPane scrollPane = new JScrollPane(menuList); // Add scroll capability
        frame.add(scrollPane, BorderLayout.CENTER); // Add list to frame

        messageArea = new JTextArea(); // Create message area
        messageArea.setEditable(false); // Non-editable area
        frame.add(new JScrollPane(messageArea), BorderLayout.EAST); // Add message area to frame

        JButton orderButton = new JButton("Order Item"); // Button to order item
        orderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MenuItem selectedItem = menuList.getSelectedValue(); // Get selected item
                if (selectedItem != null) {
                    orderSummary.put(selectedItem, orderSummary.getOrDefault(selectedItem, 0) + 1); // Update order
                    totalPrice += selectedItem.getPrice(); // Update total price
                    messageArea.append("You ordered: " + selectedItem.getName() + "\n"); // Show message
                } else {
                    messageArea.append("Please select an item to order.\n"); // Prompt to select item
                }
            }
        });

        JButton summaryButton = new JButton("Show Order Summary"); // Button to show summary
        summaryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showOrderSummary(); // Show summary window
            }
        });

        JPanel buttonPanel = new JPanel(); // Panel for buttons
        buttonPanel.add(orderButton); // Add order button
        buttonPanel.add(summaryButton); // Add summary button
        frame.add(buttonPanel, BorderLayout.SOUTH); // Add panel to frame
        frame.setVisible(true); // Show frame
    }

    // Show order summary in a new window
    // Show order summary in a new window
private void showOrderSummary() {
    JFrame summaryFrame = new JFrame("Order Summary");
    summaryFrame.setSize(300, 300);
    summaryFrame.setLayout(new BorderLayout());

    JTextArea textArea = new JTextArea();
    textArea.setEditable(false);
    textArea.append("Order Summary:\n");
    
    for (Map.Entry<MenuItem, Integer> entry : orderSummary.entrySet()) {
        MenuItem item = entry.getKey();
        int count = entry.getValue();
        textArea.append(item.getName() + ": " + count + " ordered\n");
    }
    
    // Calculate total before tax and total with tax
    double totalBeforeTax = totalPrice; // Total before tax
    double totalWithTax = totalPrice * (1 + taxRate); // Total with tax

    // Display totals
    textArea.append("\nTotal Price (before tax): $" + String.format("%.2f", totalBeforeTax) + "\n");
    textArea.append("Total Price (incl. tax): $" + String.format("%.2f", totalWithTax) + "\n");

    summaryFrame.add(new JScrollPane(textArea), BorderLayout.CENTER);

    JPanel buttonPanel = new JPanel();
    
    JButton printReceiptButton = new JButton("Print Receipt");
    printReceiptButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            if (totalPrice > 0.0) {  // Check if there are items ordered
                saveReceipt();
                summaryFrame.dispose(); // Close the summary window
            } else {
                // Display message if no items have been ordered
                JOptionPane.showMessageDialog(summaryFrame, "No items have been ordered.");
            }
        }
    });

    JButton orderMoreButton = new JButton("Order More");
    orderMoreButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            summaryFrame.dispose(); // Close the summary window
        }
    });

    buttonPanel.add(printReceiptButton);
    buttonPanel.add(orderMoreButton);
    summaryFrame.add(buttonPanel, BorderLayout.SOUTH);
    summaryFrame.setVisible(true);
}

    

    // Save the receipt to a text file
    private void saveReceipt() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("receipt.txt"))) { // Create PrintWriter for receipt
            writer.println("========================================"); // Receipt heading
            writer.println("               RECEIPT                 "); // Title
            writer.println("========================================"); // Separator
            writer.println("Item               Quantity      Price"); // Header
            writer.println("----------------------------------------"); // Separator
            for (Map.Entry<MenuItem, Integer> entry : orderSummary.entrySet()) { // Iterate through orders
                MenuItem item = entry.getKey(); // Get item
                int count = entry.getValue(); // Get quantity
                writer.printf("%-20s %-10d $%.2f%n", item.getName(), count, item.getPrice() * count); // Write item details
            }
            writer.println("----------------------------------------"); // Separator
            
            // Calculate total including tax
            double totalWithTax = totalPrice * (1 + taxRate);
            writer.printf("Total Price (incl. tax): $%.2f%n", totalWithTax); // Write total price with tax
            writer.println("========================================"); // Separator
            writer.println("Thank you for your order!"); // Thank you message
            writer.flush(); // Ensure everything is written
            JOptionPane.showMessageDialog(null, "Receipt printed to receipt.txt\nThank you for your order!"); // Confirmation
            System.exit(0); // Close application
        } catch (IOException e) { // Handle IO exceptions
            JOptionPane.showMessageDialog(null, "Error saving receipt: " + e.getMessage()); // Show error
        }
    }

    // Main method to start the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() { // Ensure GUI is created on the Event Dispatch Thread
            public void run() {
                new MenuOrderingSystem(); // Create the ordering system
            }
        });
    }
}

// Class representing a menu item
class MenuItem {
    private String name; // Item name
    private double price; // Item price

    // Constructor to initialize menu item
    public MenuItem(String name, double price) {
        this.name = name; // Set name
        this.price = price; // Set price
    }

    // Getter for item name
    public String getName() {
        return name; // Return name
    }

    // Getter for item price
    public double getPrice() {
        return price; // Return price
    }

    // Override toString for display
    @Override
    public String toString() {
        return name + " - $" + String.format("%.2f", price); // Format for display
    }
}
