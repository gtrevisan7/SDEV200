// Class representing a menu item with a name and price
public class MenuItem {
    private String name; // Name of the menu item
    private double price; // Price of the menu item

    // Constructor to initialize menu item
    public MenuItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Getter for item name
    public String getName() {
        return name;
    }

    // Getter for item price
    public double getPrice() {
        return price;
    }

    // Override toString for display
    @Override
    public String toString() {
        return name + " - $" + String.format("%.2f", price); // Format price
    }
}
